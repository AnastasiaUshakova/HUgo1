---
title: "Topic 2 is very cool!"
date: 2019-06-17T23:53:00+01:00
draft: true
hideLastModified: true
summary: "The summary image should be a custom one"
summaryImage: "summary_2.jpg"
tags: ["custom_image", "custom_summary", "code", "leaf_bundle"]
resources:
- src: summary_2.jpg
---

This is the real text of the article. 

```python
def dummy_function(arg2):
    print("dummy function for topic 2!")
    return arg2
```