---
title: "Topic 1 is very cool (again)! (Russian Edition)"
date: 2019-06-17T23:53:00+01:00
draft: true
hideLastModified: true
summary: "This summary \
is \
multiline and should be in Russian"
tags: ["custom_summary", "code"]
---

Example code:

```python
def dummy_function(arg1):
    print("dummy function")
    return arg1 
```
